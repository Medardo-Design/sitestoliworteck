import { Template } from '../types/database';
import { Star, ExternalLink } from 'lucide-react';

interface TemplateCardProps {
  template: Template;
  onSelect: (template: Template) => void;
}

export default function TemplateCard({ template, onSelect }: TemplateCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1">
      <div className="relative h-64 overflow-hidden group">
        <img
          src={template.preview_image}
          alt={template.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        {template.is_featured && (
          <div className="absolute top-4 right-4 bg-amber-500 text-white px-3 py-1 rounded-full flex items-center gap-1 text-sm font-semibold shadow-lg">
            <Star size={14} fill="currentColor" />
            <span>Vedette</span>
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="absolute bottom-4 left-4 right-4 flex gap-2">
            {template.demo_url && (
              <a
                href={template.demo_url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 bg-white text-gray-900 px-4 py-2 rounded-lg font-medium flex items-center justify-center gap-2 hover:bg-gray-100 transition-colors"
                onClick={(e) => e.stopPropagation()}
              >
                <ExternalLink size={18} />
                Démo
              </a>
            )}
            <button
              onClick={() => onSelect(template)}
              className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
            >
              Choisir
            </button>
          </div>
        </div>
      </div>

      <div className="p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-3">{template.name}</h3>

        <p className="text-gray-600 mb-4 line-clamp-2">{template.description}</p>

        <div className="space-y-2">
          {template.features.slice(0, 3).map((feature, index) => (
            <div key={index} className="flex items-center gap-2 text-sm text-gray-700">
              <div className="w-1.5 h-1.5 bg-blue-600 rounded-full"></div>
              <span>{feature}</span>
            </div>
          ))}
          {template.features.length > 3 && (
            <div className="text-sm text-gray-500 italic">
              +{template.features.length - 3} autres fonctionnalités
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
