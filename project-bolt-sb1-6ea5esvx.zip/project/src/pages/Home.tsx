import { Link } from 'react-router-dom';
import { Sparkles, Palette, Rocket, Shield, Zap } from 'lucide-react';

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100">
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-32">
        <div className="text-center">
          <div className="flex items-center justify-center gap-3 mb-6">
            <Sparkles className="text-blue-600 animate-pulse" size={60} />
          </div>
          <h1 className="text-6xl md:text-7xl font-bold text-gray-900 mb-6">
            Créez votre site web
            <span className="block text-blue-600 mt-2">en toute simplicité</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 max-w-3xl mx-auto mb-12">
            Découvrez notre collection de modèles de sites web professionnels, conçus pour
            répondre à tous vos besoins. Du e-commerce au portfolio, trouvez le design parfait
            pour votre projet.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              to="/catalog"
              className="px-8 py-4 bg-blue-600 text-white text-lg font-semibold rounded-full hover:bg-blue-700 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
            >
              Découvrir le catalogue
            </Link>
            <Link
              to="/contact"
              className="px-8 py-4 bg-white text-gray-900 text-lg font-semibold rounded-full hover:bg-gray-50 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
            >
              Nous contacter
            </Link>
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">
          Pourquoi nous choisir ?
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1">
            <div className="w-14 h-14 bg-blue-100 rounded-xl flex items-center justify-center mb-4">
              <Palette className="text-blue-600" size={28} />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">Design Moderne</h3>
            <p className="text-gray-600">
              Des designs contemporains et élégants qui reflètent les dernières tendances du web.
            </p>
          </div>

          <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1">
            <div className="w-14 h-14 bg-green-100 rounded-xl flex items-center justify-center mb-4">
              <Rocket className="text-green-600" size={28} />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">Livraison Rapide</h3>
            <p className="text-gray-600">
              Votre site web est prêt en quelques jours. Gagnez du temps et lancez-vous rapidement.
            </p>
          </div>

          <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1">
            <div className="w-14 h-14 bg-purple-100 rounded-xl flex items-center justify-center mb-4">
              <Zap className="text-purple-600" size={28} />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">Performance Optimale</h3>
            <p className="text-gray-600">
              Sites ultra-rapides et optimisés pour le référencement et l'expérience utilisateur.
            </p>
          </div>

          <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1">
            <div className="w-14 h-14 bg-amber-100 rounded-xl flex items-center justify-center mb-4">
              <Shield className="text-amber-600" size={28} />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3">Support Dédié</h3>
            <p className="text-gray-600">
              Une équipe à votre écoute pour vous accompagner dans votre projet web.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-blue-600 text-white py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Prêt à démarrer votre projet ?</h2>
          <p className="text-xl mb-8 text-blue-100">
            Explorez notre catalogue et trouvez le modèle parfait pour votre entreprise.
          </p>
          <Link
            to="/catalog"
            className="inline-block px-8 py-4 bg-white text-blue-600 text-lg font-semibold rounded-full hover:bg-gray-100 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
          >
            Voir le catalogue
          </Link>
        </div>
      </section>
    </div>
  );
}
