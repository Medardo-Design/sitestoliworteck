export interface TemplateCategory {
  id: string;
  name: string;
  description: string;
  created_at: string;
}

export interface Template {
  id: string;
  name: string;
  description: string;
  category_id: string;
  preview_image: string;
  demo_url: string | null;
  price: number;
  features: string[];
  is_featured: boolean;
  created_at: string;
  updated_at: string;
}

export interface CustomerSelection {
  id: string;
  customer_name: string;
  customer_email: string;
  template_id: string;
  status: 'pending' | 'approved' | 'completed';
  notes: string | null;
  created_at: string;
}
