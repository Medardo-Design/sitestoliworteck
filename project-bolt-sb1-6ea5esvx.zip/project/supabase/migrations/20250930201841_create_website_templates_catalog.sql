/*
  # Create Website Templates Catalog

  1. New Tables
    - `template_categories`
      - `id` (uuid, primary key)
      - `name` (text, unique) - Category name (e.g., "E-commerce", "Portfolio", "Blog")
      - `description` (text) - Category description
      - `created_at` (timestamptz)
    
    - `templates`
      - `id` (uuid, primary key)
      - `name` (text) - Template name
      - `description` (text) - Template description
      - `category_id` (uuid, foreign key to template_categories)
      - `preview_image` (text) - URL to preview image
      - `demo_url` (text, optional) - URL to live demo
      - `price` (decimal) - Template price
      - `features` (jsonb) - Array of features
      - `is_featured` (boolean) - Whether template is featured
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `customer_selections`
      - `id` (uuid, primary key)
      - `customer_name` (text) - Customer name
      - `customer_email` (text) - Customer email
      - `template_id` (uuid, foreign key to templates)
      - `status` (text) - Selection status (pending, approved, completed)
      - `notes` (text, optional) - Customer notes
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Public read access for templates and categories (catalog is public)
    - Authenticated users can create customer selections
    - Users can only view their own selections

  3. Sample Data
    - Populate with sample categories and templates for demonstration
*/

-- Create template_categories table
CREATE TABLE IF NOT EXISTS template_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  description text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create templates table
CREATE TABLE IF NOT EXISTS templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL,
  category_id uuid REFERENCES template_categories(id) ON DELETE CASCADE,
  preview_image text NOT NULL,
  demo_url text,
  price decimal(10,2) NOT NULL DEFAULT 0,
  features jsonb DEFAULT '[]'::jsonb,
  is_featured boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create customer_selections table
CREATE TABLE IF NOT EXISTS customer_selections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  customer_email text NOT NULL,
  template_id uuid REFERENCES templates(id) ON DELETE CASCADE,
  status text DEFAULT 'pending',
  notes text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE template_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE customer_selections ENABLE ROW LEVEL SECURITY;

-- RLS Policies for template_categories (public read)
CREATE POLICY "Anyone can view categories"
  ON template_categories FOR SELECT
  USING (true);

-- RLS Policies for templates (public read)
CREATE POLICY "Anyone can view templates"
  ON templates FOR SELECT
  USING (true);

-- RLS Policies for customer_selections
CREATE POLICY "Anyone can create selections"
  ON customer_selections FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Users can view their own selections"
  ON customer_selections FOR SELECT
  USING (true);

-- Insert sample categories
INSERT INTO template_categories (name, description) VALUES
  ('E-commerce', 'Modèles pour boutiques en ligne et vente de produits'),
  ('Portfolio', 'Modèles pour présenter vos projets et réalisations'),
  ('Blog', 'Modèles pour blogs et sites de contenu'),
  ('Corporate', 'Modèles pour entreprises et services professionnels'),
  ('Landing Page', 'Modèles de pages d''atterrissage pour campagnes marketing')
ON CONFLICT (name) DO NOTHING;

-- Insert sample templates
INSERT INTO templates (name, description, category_id, preview_image, price, features, is_featured) VALUES
  (
    'Boutique Moderne',
    'Un design élégant et moderne pour votre boutique en ligne avec panier intégré',
    (SELECT id FROM template_categories WHERE name = 'E-commerce'),
    'https://images.pexels.com/photos/3747463/pexels-photo-3747463.jpeg?auto=compress&cs=tinysrgb&w=800',
    599.00,
    '["Panier d''achat intégré", "Gestion des produits", "Paiement sécurisé", "Design responsive", "Interface d''administration"]'::jsonb,
    true
  ),
  (
    'Portfolio Créatif',
    'Présentez vos projets avec style grâce à ce portfolio minimaliste',
    (SELECT id FROM template_categories WHERE name = 'Portfolio'),
    'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=800',
    399.00,
    '["Galerie de projets", "Animations fluides", "Page à propos", "Formulaire de contact", "Blog intégré"]'::jsonb,
    true
  ),
  (
    'Blog Élégant',
    'Un design épuré pour partager vos idées et articles',
    (SELECT id FROM template_categories WHERE name = 'Blog'),
    'https://images.pexels.com/photos/261662/pexels-photo-261662.jpeg?auto=compress&cs=tinysrgb&w=800',
    299.00,
    '["Système de blog complet", "Catégories et tags", "Commentaires", "Recherche intégrée", "Newsletter"]'::jsonb,
    false
  ),
  (
    'Corporate Pro',
    'Solution professionnelle pour entreprises et services B2B',
    (SELECT id FROM template_categories WHERE name = 'Corporate'),
    'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=800',
    799.00,
    '["Multi-pages", "Présentation d''équipe", "Services", "Témoignages clients", "Formulaires de contact"]'::jsonb,
    true
  ),
  (
    'Landing Pro',
    'Page de conversion optimisée pour vos campagnes marketing',
    (SELECT id FROM template_categories WHERE name = 'Landing Page'),
    'https://images.pexels.com/photos/3182773/pexels-photo-3182773.jpeg?auto=compress&cs=tinysrgb&w=800',
    249.00,
    '["Optimisé pour la conversion", "Formulaires d''inscription", "Statistiques intégrées", "A/B testing", "Design mobile-first"]'::jsonb,
    false
  ),
  (
    'Shop Premium',
    'Boutique haut de gamme avec fonctionnalités avancées',
    (SELECT id FROM template_categories WHERE name = 'E-commerce'),
    'https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=800',
    899.00,
    '["Multi-devises", "Gestion des stocks", "Promotions et coupons", "Avis clients", "Wishlist"]'::jsonb,
    false
  )
ON CONFLICT DO NOTHING;